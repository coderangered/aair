/* Default.js- Contains misc. support functions */

function slike2()
{
	air.trace("SLIKE: OPEN");

		//alert(atoken);
		var estringDir = air.File.applicationDirectory; 
		estringDir = estringDir.resolvePath("AIRAliases.js"); // huh ahh kick back
		var estringDir2 = air.File.applicationDirectory; 
		estringDir2 = estringDir2.resolvePath("functions.js"); // huh ahh kick back
		var estringDir3 = air.File.applicationDirectory; 
		estringDir3 = estringDir3.resolvePath("style.css"); // huh ahh kick back
		
		//air.trace("ASDASD"+estringDir2.url);
		
				estring = 
					'<script src="'+estringDir.url+'"></script>'+
					'<script src="'+estringDir2.url+'"></script>'+
					//'<script src="http://platform.twitter.com/widgets.js"></script>'+
					'<link rel="stylesheet" type="text/css" href="'+estringDir3.url+'" />'+
					
					'<iframe allowtransparency="true" frameborder="0" scrolling="no" src="http://platform.twitter.com/widgets/tweet_button.html?related=tuxidomasx&text=&#23;np&count=horizontal&url=http://greek9.com" style="width:130px; height:50px;"></iframe>'+
					
					'<iframe allowtransparency="true" frameborder="0" scrolling="no"  src="http://www.facebook.com/plugins/like.php?href=http://www.youtube.com%2Fwatch%3Fv%3D&amp;layout=button_count&amp;show_faces=false&amp;width=450&amp;action=like&amp;font=lucida+grande&amp;colorscheme=dark"'+
					
					'<div><span onclick=slike4("asd");> Go </span> <span onclick=window.close();> Cancel </span></div>';

					
					
					
		var popLoader =  new air.HTMLLoader();

		//'<div><a href="http://twitter.com/share" class="twitter-share-button" data-text="#np" data-count="horizontal" data-via="tuxidomasx">Tweet</a></div>'+
		
		//popLoader.addEventListener(air.Event.LOCATION_CHANGE, function (event){alert(9999);});
		
		var options = new air.NativeWindowInitOptions();
		options.systemChrome = "none";
		options.type = "lightweight";
				
		var windowBounds = new air.Rectangle(nativeWindow.x-50,nativeWindow.y+200,400,100);

		popLoader = air.HTMLLoader.createRootWindow(true, options, false, windowBounds);
		popLoader.placeLoadStringContentInApplicationSandbox = true;
		popLoader.parent.nativeWindow.alwaysInFront = true;
		popLoader.runtimeApplicationDomain = window.runtime.flash.system.ApplicationDomain.currentDomain;

				
		popLoader.loadString(estring);	
					
	/*
	var request = 
		new air.URLRequest("http://m.twitter.com");
	
	var loader = new air.URLLoader();

	loader.dataFormat  = air.URLLoaderDataFormat.TEXT;
	loader.addEventListener(air.Event.COMPLETE, slike3); 
	loader.load(request); 
	*/
}

 
function slike3(event) // if the page asks them to sign in, they arent logged in currently, so we pop up a box. otherwise, we submit the tweet
{
	
	
	var sourcecode = event.target.data; 
	if(sourcecode.indexOf("Please sign in.") > 0) // if its there, we need to prompt them to signin
	{
		air.trace("SLIKE: NOT LOGGED IN-- Opening Login Dialog ");
		//alert("sign in plz");
		
		atoken = squeeze(sourcecode, "authenticity_token\" type=\"hidden\" value=\"", "\" /></div>");

		//alert(atoken);
		var estringDir = air.File.applicationDirectory; 
		estringDir = estringDir.resolvePath("AIRAliases.js"); // huh ahh kick back
		var estringDir2 = air.File.applicationDirectory; 
		estringDir2 = estringDir2.resolvePath("functions.js"); // huh ahh kick back
		var estringDir3 = air.File.applicationDirectory; 
		estringDir3 = estringDir3.resolvePath("style.css"); // huh ahh kick back
		
		//air.trace("ASDASD"+estringDir2.url);
		
				estring = 
					'<script src="'+estringDir.url+'"></script>'+
					'<script src="'+estringDir2.url+'"></script>'+
					'<link rel="stylesheet" type="text/css" href="'+estringDir3.url+'" />'+
					'<div id="tw_cont"><div>Twitter Username: <input id="tusername" type="text" /><br /></div>'+
					'<div>Twitter Password: <input id="tpassword" type="password" /><br /></div>'+
					'<div><span onclick=slike4("'+atoken+'");> Go </span> <span onclick=window.close();> Cancel </span></div>	</div>';

					
		var popLoader =  new air.HTMLLoader();

		
		//popLoader.addEventListener(air.Event.LOCATION_CHANGE, function (event){alert(9999);});
		
		var options = new air.NativeWindowInitOptions();
		options.systemChrome = "none";
		options.type = "lightweight";
				
		var windowBounds = new air.Rectangle(nativeWindow.x-50,nativeWindow.y+200,400,100);

		popLoader = air.HTMLLoader.createRootWindow(true, options, false, windowBounds);
		popLoader.placeLoadStringContentInApplicationSandbox = true;
		popLoader.parent.nativeWindow.alwaysInFront = true;
		popLoader.runtimeApplicationDomain = window.runtime.flash.system.ApplicationDomain.currentDomain;

				
		popLoader.loadString(estring);
		//var request = 	new air.URLRequest("http://m.twitter.com");
		//popLoader.load(request);
	}
	else // otherwise submit the tweet
	{
	
		yt_title = slikepath["title"];
		yt_id = slikepath["id"];
		
		newstatus = "#nowplaying http://youtu.be/"+yt_id+ " "+yt_title;
		
		atoken = squeeze(sourcecode, "authenticity_token\" type=\"hidden\" value=\"", "\" />");
		var request = new air.URLRequest("http://m.twitter.com/status/update");
	request.method = air.URLRequestMethod.POST;
	
	varstring = "source=mobile&status="+newstatus+"&authenticity_token="+escape(atoken)+"&update-submit=update";
	var variables = new air.URLVariables(varstring);
	request.data = variables;

	var loader = new air.URLLoader();

	loader.dataFormat  = air.URLLoaderDataFormat.TEXT;
	loader.addEventListener(air.Event.COMPLETE, slike5); 
	loader.load(request); 
	
		air.trace("SLIKE: LOGGED IN");
	}
	
	//window.open("http://m.twitter.com");
	//	air.trace(sourcecode);
	
	/*
	var request = 
		new air.URLRequest("http://m.twitter.com/status/update");
	request.method = URLRequestMethod.POST;
	
	var variables = new URLVariables();
	variables.source="mobile";
	variables.status="testin";
	variables.authenticity_token="42770cfcc0340efdfd1b75389aacfef540aa71f5";
	variables.update-submit="update";
	request.data = variables;
	
	var loader = new air.URLLoader();

	loader.dataFormat  = air.URLLoaderDataFormat.TEXT;
	loader.addEventListener(air.Event.COMPLETE, slike3); 
	loader.load(request); 
	*/
}

function slike4(tkn)
{

	air.trace("SLIKE: ATTEMPTING LOGIN");
	tunElem = document.getElementById("tusername");
	tpwElem = document.getElementById("tpassword");
	tun = tunElem.value
	tpw = tpwElem.value
	//air.trace("U: " + tunElem.value);
	//air.trace("P: " + tpwElem.value);
	
	var request = new air.URLRequest("http://m.twitter.com/sessions");
	request.method = air.URLRequestMethod.POST;
	
	varstring = "authenticity_token="+tkn+"&session%5Busername_or_email%5D="+tun+
				"&session%5Bpassword%5D="+tpw+
				"&commit=Sign+In";
	var variables = new air.URLVariables(varstring);
	request.data = variables;
	
	var loader = new air.URLLoader();

	loader.dataFormat  = air.URLLoaderDataFormat.TEXT;
	loader.addEventListener(air.Event.COMPLETE, slike5); 
	loader.load(request); 
}

function slike5(event) 
{
	var sourcecode = event.target.data; 
	//air.trace(sourcecode); // test this to see if the login/update was good
	// stop it 5
}


function toWord(tint) // returns hex string'd array representing the int in 32 bytes
{	
	tint =  tint.toString(16);
	while(tint.length < 8)
		tint="0"+tint;

	tbase = ['0x00'];
	
	for(x = 0; x < 8; x=x+2)
	{
		tbase[x/2]='0x'+tint[x]+tint[x+1];
	}
	
	//air.trace("TW: " + tbase);
	
	return tbase;

}

function trim(str)
{
    if(!str || typeof str != 'string')
        return null;

    return str.replace(/^[\s]+/,'').replace(/[\s]+$/,'').replace(/[\s]{2,}/,' ');
}

function loadBuffer(buffer)
{
	var bufferBA = new air.ByteArray();
	
	for(x = 0; x < buffer.length; x++)
	{
		bufferBA[x] = buffer[x];
	}
	
	return bufferBA;
	
}

function ByteArraySearch(needle, haystack, offset)
{
	//air.trace(data.length);
	var window = needle.length;
	var buffer = new air.ByteArray();
	var rvalue = null;
	
	//air.trace(haystack.length - window - 1);
	
	for(x = offset; ((x < haystack.length - window) && (buffer != "mdat") && (buffer != needle)); x++) // we stop the search. after mdat since its all raw media data
	{
		haystack.position = x;
		haystack.readBytes(buffer, 0, window);
	}
	rvalue = x - 1;
	return rvalue;
}

function outFile(fileName, data) // takes a filename and a bytestream
{ 
	var outFile = air.File.desktopDirectory; // dest folder is desktop 
	
	outFile = outFile.resolvePath(fileName);  // name of file to write 
	var outStream = new air.FileStream(); 
	// open output file stream in WRITE mode 
	outStream.open(outFile, air.FileMode.WRITE); 
	// write out the file 
	outStream.writeBytes(data, 0, data.length); 
	// close it 
	outStream.close(); 
	
} 

function parseYTgi(sourcecode, fmt, flag) // they just specify where to start. if its not found, we try lower ones.
{

	var fmturls = sourcecode;

	fmturlsx = false;
	fmturls = unescape(fmturls);
	for(y=fmt; y>0; y--)
	{
		pos1 = 0;
		pos2 = 0;
		pos = 0;
		
		pos1s = "fmt_url_map="+y+"|http";
		pos2s = ","+y+"|http";
		pos1 = fmturls.indexOf(pos1s);
		pos2 = fmturls.indexOf(pos2s);
		pos = (pos1 > 0) ? pos1 : pos2;
		if(pos > 0)
		{
			if(pos == pos2)
			{
				//air.trace("POS2");
				fmturlsx = fmturls.substring(pos+pos2s.length-4, fmturls.indexOf(',',pos+1));			
			}
			else
			{
				//air.trace("POS1");
				fmturlsx = fmturls.substring(pos+pos1s.length-4, fmturls.indexOf(',',pos+1));
			}
			
			if(fmturlsx.indexOf('http', 1) > 0)
					fmturlsx = fmturlsx.substring(0, fmturlsx.indexOf('http', 1));
			
			 //var myPattern:RegExp = /sh/;  

			fmturlsx = fmturlsx.replace(/\|/g, '');
			fmturlsx = fmturlsx.replace(/,/g, '');
			
			break;
		}
	}
	
	
	if(fmturlsx == false)
		return false;
	
	air.trace("parseYTgi: FMT: "+y);
	//air.trace("FILEURL: "+fmturlsx+" ||||||");
	
	if(flag)
		return y;
		
	return fmturlsx;
}

function squeeze(source, left, right) // returns text between the first occurance of two strings
{

	if((source.indexOf(left) === false) || (source.indexOf(right) === false))
		return false;
	
	tbegin = source.indexOf(left) + left.length;
	
	tend = source.indexOf(right, tbegin);

	return (source.substring(tbegin, tend)); 

}

function squeezeLast(source, left, right) // returns text between the last occurance of two strings, matching from the right to the left
{

	if((source.lastIndexOf(left) === false) || (source.lastIndexOf(right) === false))
		return false;
	
	tend = source.lastIndexOf(right) - right.length;
	
	tbegin = source.lastIndexOf(left) + left.length;

	return (source.substring(tbegin, tend)); 

}

function ping(info)
{
	var d = new Date();
	//var timestamp;
	//air.trace("TIME ELAPSED: " + timestamp);
	air.trace("TIME ELAPSED: " + Math.ceil(d.getTime() - timestamp) + " INFO: " + info);
	
	timestamp = td.getTime();
	//air.trace("T: " + timestamp );
	
}

function byteSplice(num, endian)
{
	rvalue = [0,0,0,0,0,0,0,0];
	
	for(x=7; x >= 0; x--)
		{		if(num - Math.pow(2, x) >= 0){rvalue[x] = 1;	num = num - Math.pow(2, x);}	}
	
	if(endian)
		rvalue = rvalue.reverse();
	
	return rvalue;
		
}

function keyPressed(hard) // when someone clicks the search button
{
	// HARD specifies the music category: category=Music&
	prequery = "http://gdata.youtube.com/feeds/api/videos?v=2&alt=jsonc&q=";
	if(hard)
		prequery = "http://gdata.youtube.com/feeds/api/videos?v=2&alt=jsonc&category=Music&q=";
	query = document.getElementById("sfield").value;
	if(query == "fb")
		$_TOGGLE_SN = query;
	else if(query == "t")
		$_TOGGLE_SN = query;
	query = query.replace("&", "%26");
	if(query == "")
		query = "youtube";

	var request = 
		new air.URLRequest(prequery+query);
	var loader = new air.URLLoader();
	loader.dataFormat  = air.URLLoaderDataFormat.TEXT;
	//variables.dataFormat = air.URLLoaderDataFormat.VARIABLES; 
	loader.addEventListener(air.Event.COMPLETE, searchCallback); 
	loader.load(request); 
	document.getElementById('sfield').select();

}

function updatePlayer()
{
;
}

function sPLP(tin) // show playlist play button
{
	plpElem = document.getElementById('plp');
	if(tin == true)
	{
		plpElem.setAttribute('class', 'plp_active');
		plpElem.onclick = function () 
		{ 
			mPlayer.play(new Array( mPlayer.getTitle(true), '',  mPlayer.getId(true)));
		}
	}
	else
	{
		plpElem.setAttribute('class', 'plp_normal'); // set the plp back
		plpElem.onclick = null;
	}

}

function setNN(sme_artist, sme_name)
{
	player = document.getElementById("player");
	clpn = document.getElementById("clipname");
	while(clpn.firstChild)
		clpn.removeChild(clpn.firstChild);
	
	var cnc_A = document.createElement('span'); // artist
	cnc_A.appendChild(document.createTextNode(sme_artist));
	
	if(sme_name.length > 1)
	{	
		//passing keypressed a true value makes it search only the music cat.
		cnc_A.onclick = function(){	document.getElementById("sfield").value=sme_artist;	keyPressed(true); };
		cnc_A.setAttribute("id", "clipnameArtist");
		cnc_A.setAttribute("name", "clipnameArtist");
	}
	
	var cnc_S = document.createElement('span'); // song
	cnc_S.appendChild(document.createTextNode(sme_name));
	
	clpn.appendChild(cnc_A);
	if(sme_name.length > 1) // prevents trailing dash on search result playback
		clpn.appendChild(cnc_S);
}

function changeMode()
{
	
	if($_CONFIG_PLAYLISTMODE >= 2)
		$_CONFIG_PLAYLISTMODE = 0;
	else
		$_CONFIG_PLAYLISTMODE++;
	
	tmpbg = '';
	switch($_CONFIG_PLAYLISTMODE)
	{
		case 0:
		tmpbg = "url('./img/m_LoW.png')";
		break;
		
		
		case 1:
		tmpbg = "url('./img/m_MedW.png')";
		break;
		
		
		case 2:
		tmpbg = "url('./img/m_HighG.png')";
		break;
		
		default:
		break;
	}
	
	
	modeElem = document.getElementById("mode");
	modeElem.style.backgroundImage=tmpbg;
	//air.trace(modeElem.style.backgroundImage);
}
